<div class="wrap">
    <div id="posts-remover-app" class="bpr-about">
        <h2>About</h2>
    </div>
</div>